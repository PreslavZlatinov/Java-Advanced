package Exercise.GenericBox;

import java.util.ArrayList;
import java.util.List;

public class Box<T extends Comparable<T>> {
    private List<T> elements;

    public Box() {
        this.elements = new ArrayList<>();
    }

    public List<T> getElements() {
        return elements;
    }

    public void add(T element){
        this.elements.add(element);
    }

    public <T> void swap(List<T> list, int pos1, int pos2){
        T firstElement = list.get(pos1);
        T secondElement = list.get(pos2);

        list.remove(secondElement);
        list.add(pos2,firstElement);

        list.remove(firstElement);
        list.add(pos1,secondElement);

    }

    public int count(T element){
        int count = 0;
        for (T elem : elements) {
            if(elem.compareTo(element) > 0){
                count++;
            }
        }

        return count;
    }

    @Override
    public String toString() {
       StringBuilder sb = new StringBuilder();

        for (T element : elements) {
            sb.append(String.format("%s: %s%n",element.getClass().getName(),element.toString()));
        }

        return sb.toString();
    }
}
